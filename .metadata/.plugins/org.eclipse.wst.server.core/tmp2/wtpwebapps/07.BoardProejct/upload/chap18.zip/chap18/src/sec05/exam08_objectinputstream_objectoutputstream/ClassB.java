package sec05.exam08_objectinputstream_objectoutputstream;

import java.io.Serializable;

public class ClassB implements Serializable {
	int field1;
}

