package sec05.exam08_objectinputstream_objectoutputstream;

public class Parent {
	public String field1;
}
