package verify;
public class Exercise03 {
	public static void main(String[] args) {
		int score = 85;
		String result = (!(score>90))? "��":"��";
		System.out.println(result);
	}
}

