package sec02.exam06_boolean;
public class BooleanExample {
	public static void main(String[] args) {
		boolean stop = true;
		if(stop) {
			System.out.println("�����մϴ�.");
		} else {
			System.out.println("�����մϴ�.");
		}
	} 
}


