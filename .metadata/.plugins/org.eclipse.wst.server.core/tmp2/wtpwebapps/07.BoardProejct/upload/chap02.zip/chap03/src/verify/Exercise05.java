package verify;
public class Exercise05 {
	public static void main(String[] args) {
		int value = 356;
		System.out.println(   356 / 100 * 100    );
	}
}



